package com.funkinhub.mobile

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

private val Bg = Color(0xFF111018)
private val Panel = Color(0xFF211E2A)
private val Pink = Color(0xFFFF4D9B)
private val Lime = Color(0xFFB8FF55)
private val Muted = Color(0xFFAAA4B4)
private val client = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()

data class ModItem(val id: String, val name: String, val author: String, val url: String, val description: String = "")
data class GBFile(val name: String, val url: String, val size: Long, val description: String)
data class StagedMod(val name: String, val folder: File, val meta: String)

class MainActivity : ComponentActivity() {
    private var chosenTree by mutableStateOf<Uri?>(null)
    private var importSignal by mutableIntStateOf(0)
    private val importZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val stageRoot = File(cacheDir, "staged").apply { mkdirs() }
                val zipFile = File(cacheDir, "incoming-${System.currentTimeMillis()}.zip")
                contentResolver.openInputStream(uri)?.use { input -> zipFile.outputStream().use { input.copyTo(it) } }
                    ?: error("Couldn't read the selected ZIP.")
                val temp = File(stageRoot, "extract-${System.currentTimeMillis()}").apply { mkdirs() }
                java.util.zip.ZipInputStream(zipFile.inputStream()).use { zis ->
                    while (true) {
                        val entry = zis.nextEntry ?: break
                        val out = File(temp, entry.name).canonicalFile
                        require(out.path.startsWith(temp.canonicalPath + File.separator) || out == temp.canonicalFile) {
                            "Unsafe ZIP entry blocked."
                        }
                        if (entry.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { output -> zis.copyTo(output) }
                        }
                        zis.closeEntry()
                    }
                }
                zipFile.delete()
                var modRoot = temp
                if (!File(modRoot, "_polymod_meta.json").exists()) {
                    val children = modRoot.listFiles()?.filter { it.isDirectory } ?: emptyList()
                    if (children.size == 1 && File(children[0], "_polymod_meta.json").exists()) modRoot = children[0]
                }
                val meta = File(modRoot, "_polymod_meta.json")
                require(meta.exists()) { "This ZIP doesn't have _polymod_meta.json at its mod root. It may not be an official FNF V-Slice mod." }
                val metaJson = JSONObject(meta.readText())
                val safe = (metaJson.optString("title").ifBlank { modRoot.name })
                    .replace(Regex("[^A-Za-z0-9 _.-]"), "_").take(70)
                val finalFolder = File(stageRoot, safe).apply {
                    if (exists()) deleteRecursively()
                }
                if (modRoot == temp) {
                    check(temp.renameTo(finalFolder)) { "Couldn't stage the extracted mod." }
                } else {
                    check(modRoot.renameTo(finalFolder)) { "Couldn't stage the extracted mod." }
                    temp.deleteRecursively()
                }
                importSignal++
            } catch (_: Exception) {
                // UI refresh still occurs; failed import leaves no installable entry.
            }
        }
    }
    private val chooseModsFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            chosenTree = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Lime, secondary = Pink,
                onBackground = Color.White, onSurface = Color.White
            )) {
                HubScreen(
                    stagedDir = File(cacheDir, "staged").apply { mkdirs() },
                    selectedTree = chosenTree,
                    importSignal = importSignal,
                    onImportZip = { importZip.launch(arrayOf("application/zip", "application/octet-stream")) },
                    onOpenUrl = { url -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) },
                    onChooseFolder = { chooseModsFolder.launch(null) },
                    onOpenFnf = {
                        val launch = packageManager.getLaunchIntentForPackage("me.funkin.fnf")
                        if (launch != null) startActivity(launch)
                        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=me.funkin.fnf")))
                    },
                    onInstall = { mod -> copyToGameFolder(mod) },
                    onFetchFiles = { mod -> fetchGameBananaFiles(mod.id) },
                    onDownloadFile = { mod, file -> downloadAndStage(mod, file) }
                )
            }
        }
    }

    private suspend fun fetchGameBananaFiles(modId: String): List<GBFile> = withContext(Dispatchers.IO) {
        val url = "https://gamebanana.com/apiv11/Mod/${Uri.encode(modId)}?_csvProperties=_aFiles"
        val request = Request.Builder().url(url).header("User-Agent", "FunkinHubAndroid/0.3").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("GameBanana returned HTTP ${response.code}")
            val json = JSONObject(response.body?.string() ?: error("Empty GameBanana response"))
            val files = json.optJSONArray("_aFiles") ?: JSONArray()
            buildList {
                for (i in 0 until files.length()) {
                    val item = files.optJSONObject(i) ?: continue
                    val fileUrl = item.optString("_sDownloadUrl")
                    if (!fileUrl.startsWith("https://")) continue
                    add(GBFile(
                        item.optString("_sFile", "Download ${i + 1}"), fileUrl,
                        item.optLong("_nFilesize", 0L), item.optString("_sDescription", "")
                    ))
                }
            }
        }
    }

    private suspend fun downloadAndStage(mod: ModItem, file: GBFile): String = withContext(Dispatchers.IO) {
        require(file.url.startsWith("https://")) { "Only secure HTTPS downloads are allowed." }
        val request = Request.Builder().url(file.url).header("User-Agent", "FunkinHubAndroid/0.3").build()
        val downloadDir = File(cacheDir, "downloads").apply { mkdirs() }
        val zip = File(downloadDir, "${mod.id}-${System.currentTimeMillis()}.zip")
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Download failed: HTTP ${response.code}")
            val body = response.body ?: error("Empty download")
            require(body.contentLength() <= 300L * 1024 * 1024 || body.contentLength() == -1L) { "File exceeds the 300 MB limit." }
            body.byteStream().use { input -> zip.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024); var total = 0L
                while (true) {
                    val count = input.read(buffer); if (count < 0) break
                    total += count
                    require(total <= 300L * 1024 * 1024) { "File exceeds the 300 MB limit." }
                    output.write(buffer, 0, count)
                }
            } }
        }
        try {
            val staging = File(cacheDir, "staged").apply { mkdirs() }
            val temp = File(staging, "download-${System.currentTimeMillis()}").apply { mkdirs() }
            var entries = 0; var expanded = 0L
            ZipInputStream(zip.inputStream().buffered()).use { zis ->
                while (true) {
                    val entry = zis.nextEntry ?: break
                    entries++; require(entries <= 10000) { "ZIP contains too many entries." }
                    val out = File(temp, entry.name).canonicalFile
                    require(out.path.startsWith(temp.canonicalPath + File.separator) || out == temp.canonicalFile) { "Unsafe ZIP path blocked." }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val n = zis.read(buffer); if (n < 0) break
                                expanded += n; require(expanded <= 1024L * 1024 * 1024) { "Expanded ZIP exceeds 1 GB." }
                                output.write(buffer, 0, n)
                            }
                        }
                    }
                    zis.closeEntry()
                }
            }
            var root = temp
            if (!File(root, "_polymod_meta.json").exists()) {
                val dirs = root.listFiles()?.filter { it.isDirectory } ?: emptyList()
                if (dirs.size == 1 && File(dirs[0], "_polymod_meta.json").exists()) root = dirs[0]
            }
            val meta = File(root, "_polymod_meta.json")
            require(meta.exists()) { "Downloaded ZIP is not recognized as a V-Slice / Polymod mod (missing _polymod_meta.json)." }
            JSONObject(meta.readText())
            val title = JSONObject(meta.readText()).optString("title").ifBlank { mod.name }
            val safe = title.replace(Regex("[^A-Za-z0-9 _.-]"), "_").take(70).ifBlank { "FNF Mod" }
            val dest = File(staging, safe).apply { if (exists()) deleteRecursively() }
            if (root == temp) check(temp.renameTo(dest)) { "Could not save mod to library." }
            else { check(root.renameTo(dest)) { "Could not save mod to library." }; temp.deleteRecursively() }
            "Downloaded and added ${dest.name} to your library."
        } finally { zip.delete() }
    }

    private fun copyToGameFolder(mod: StagedMod): String {
        val tree = chosenTree ?: return "Choose the game's mods folder first."
        val root = DocumentFile.fromTreeUri(this, tree) ?: return "Folder permission is unavailable."
        return try {
            val existing = root.findFile(mod.folder.name)
            if (existing != null) return "A folder with that name already exists. Remove it in the game folder first."
            val target = root.createDirectory(mod.folder.name) ?: return "Android didn't allow creating a mod folder here."
            copyFolderToDocument(mod.folder, target)
            "Installed ${mod.name}. Restart Friday Night Funkin' to load it."
        } catch (e: Exception) {
            "Couldn't write to that folder: ${e.message}. Use FNF's own OPEN DATA FOLDER option and follow the manual import guide."
        }
    }

    private fun copyFolderToDocument(source: File, dest: DocumentFile) {
        source.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                val sub = dest.createDirectory(child.name ?: "folder") ?: error("Couldn't create folder")
                copyFolderToDocument(child, sub)
            } else {
                val out = dest.createFile("application/octet-stream", child.name ?: "file") ?: error("Couldn't create file")
                contentResolver.openOutputStream(out.uri)?.use { output -> child.inputStream().use { it.copyTo(output) } }
                    ?: error("Couldn't write file")
            }
        }
    }
}

@Composable
private fun HubScreen(
    stagedDir: File,
    selectedTree: Uri?,
    importSignal: Int,
    onImportZip: () -> Unit,
    onOpenUrl: (String) -> Unit,
    onChooseFolder: () -> Unit,
    onOpenFnf: () -> Unit,
    onInstall: (StagedMod) -> String,
    onFetchFiles: suspend (ModItem) -> List<GBFile>,
    onDownloadFile: suspend (ModItem, GBFile) -> String
) {
    var tab by remember { mutableStateOf("Discover") }
    var query by remember { mutableStateOf("") }
    var mods by remember { mutableStateOf<List<ModItem>>(emptyList()) }
    var staged by remember { mutableStateOf<List<StagedMod>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Search GameBanana for Friday Night Funkin' mods.") }
    var selected by remember { mutableStateOf<ModItem?>(null) }
    var busy by remember { mutableStateOf(false) }
    var availableFiles by remember { mutableStateOf<List<GBFile>>(emptyList()) }
    var fileError by remember { mutableStateOf("") }
    var downloading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun refreshStaged() {
        staged = stagedDir.listFiles()?.filter { it.isDirectory }?.mapNotNull { folder ->
            val meta = File(folder, "_polymod_meta.json")
            if (meta.exists()) StagedMod(folder.name, folder, meta.readText()) else null
        } ?: emptyList()
    }
    LaunchedEffect(Unit, importSignal) { refreshStaged() }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Lime, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Text("♫", color = Bg, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("FUNKIN' HUB", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text("MOBILE MOD STATION", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
            }
            Text("ANDROID", color = Lime, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Discover", "Staged", "Install").forEach { item ->
                FilterChip(selected = tab == item, onClick = { tab = item }, label = { Text(item) })
            }
        }
        when (tab) {
            "Discover" -> {
                Column(Modifier.padding(18.dp)) {
                    Text("FIND YOUR NEXT MOD.", fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("Official FNF Mobile · V-Slice / Polymod", color = Lime, fontSize = 11.sp)
                    Spacer(Modifier.height(15.dp))
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search GameBanana...") }, singleLine = true,
                        trailingIcon = { IconButton(onClick = {
                            loading = true
                            scope.launch {
                                try { mods = searchGameBanana(query); status = "${mods.size} results found." }
                                catch (e: Exception) { status = "Search failed: ${e.message}" }
                                loading = false
                            }
                        }) { Icon(Icons.Default.Search, contentDescription = "Search", tint = Lime) } })
                    Spacer(Modifier.height(10.dp))
                    Text(status, color = Muted, fontSize = 11.sp)
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Lime)
                }
                LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(mods) { mod ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text(mod.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("by ${mod.author}  ·  #${mod.id}", color = Muted, fontSize = 10.sp)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { selected = mod }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)) { Text("GET MOD", fontWeight = FontWeight.Black) }
                                    OutlinedButton(onClick = { /* detail page is opened in detail view */ selected = mod }) { Text("DETAILS") }
                                }
                            }
                        }
                    }
                }
            }
            "Staged" -> {
                Column(Modifier.padding(18.dp)) {
                    Text("READY TO INSTALL", fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("Import a V-Slice / Polymod ZIP. Compatibility still depends on the mod's target API version.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onImportZip, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)) {
                        Text("IMPORT MOD ZIP", fontWeight = FontWeight.Black)
                    }
                }
                LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
                    items(staged) { mod ->
                        Card(Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(14.dp)) {
                                Text(mod.name, fontWeight = FontWeight.Bold)
                                Text("V-Slice / Polymod metadata detected", color = Lime, fontSize = 10.sp)
                                TextButton(onClick = { tab = "Install" }) { Text("INSTALL THIS MOD") }
                            }
                        }
                    }
                    if (staged.isEmpty()) item { Text("No staged mods yet. Search and download a compatible mod first.", color = Muted, modifier = Modifier.padding(8.dp)) }
                }
            }
            else -> {
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    Text("INSTALL TO FNF", fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(7.dp))
                    Text("Select an accessible game mods folder, then copy a validated mod into it.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = onImportZip) { Text("IMPORT MOD ZIP") }
                    Spacer(Modifier.height(16.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(15.dp)) {
                            Text("DESTINATION FOLDER", color = Lime, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(if (selectedTree == null) "No folder selected" else "A folder has been selected", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = onChooseFolder) { Text("CHOOSE MODS FOLDER") }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("STAGED MODS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(staged) { mod ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(mod.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("Metadata verified", color = Lime, fontSize = 10.sp)
                                    }
                                    Button(onClick = { status = onInstall(mod) }, enabled = selectedTree != null,
                                        colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)) { Text("INSTALL") }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onOpenFnf, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Pink, contentColor = Bg)) {
                        Text("OPEN FRIDAY NIGHT FUNKIN'", fontWeight = FontWeight.Black)
                    }
                    Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
    }

    if (selected != null) {
        val mod = selected!!
        LaunchedEffect(mod.id) {
            busy = true; fileError = ""; availableFiles = emptyList()
            try { availableFiles = onFetchFiles(mod); if (availableFiles.isEmpty()) fileError = "No downloadable files were returned by GameBanana." }
            catch (e: Exception) { fileError = "Couldn't load files: ${e.message}" }
            busy = false
        }
        AlertDialog(
            onDismissRequest = { if (!downloading) selected = null },
            title = { Text(mod.name) },
            text = {
                Column(Modifier.heightIn(max = 380.dp)) {
                    Text("by ${mod.author} · GameBanana #${mod.id}", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Lime); Text("Loading GameBanana files…", color = Muted) }
                    if (fileError.isNotBlank()) Text(fileError, color = Pink, fontSize = 12.sp)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(availableFiles) { file ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                Column(Modifier.fillMaxWidth().padding(10.dp)) {
                                    Text(file.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    if (file.size > 0) Text("${file.size / (1024 * 1024)} MB", color = Muted, fontSize = 10.sp)
                                    if (file.description.isNotBlank()) Text(file.description.take(140), color = Muted, fontSize = 10.sp)
                                    Button(enabled = !downloading, onClick = {
                                        downloading = true
                                        scope.launch {
                                            try {
                                                val result = onDownloadFile(mod, file)
                                                status = result
                                                selected = null
                                            } catch (e: Exception) { fileError = "Download failed: ${e.message}" }
                                            downloading = false
                                        }
                                    }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)) {
                                        Text(if (downloading) "DOWNLOADING…" else "DOWNLOAD & CHECK ZIP", fontWeight = FontWeight.Black)
                                    }
                                }
                            }
                        }
                    }
                    if (downloading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Lime)
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }, enabled = !downloading) { Text("CLOSE") } },
            dismissButton = { TextButton(onClick = { onOpenUrl(mod.url) }) { Text("OPEN GAMEBANANA PAGE") } }
        )
    }
}

private suspend fun searchGameBanana(query: String): List<ModItem> = withContext(Dispatchers.IO) {
    val url = "https://gamebanana.com/apiv11/Util/Search/Results?_sSearchString=${Uri.encode(query)}&_sModelName=Mod&_idGameRow=8694&_nPage=1&_nPerpage=25"
    val request = Request.Builder().url(url).header("User-Agent", "FunkinHubAndroid/0.3").build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("GameBanana HTTP ${response.code}")
        val body = response.body?.string() ?: error("Empty response")
        val json = JSONObject(body)
        val records = json.optJSONArray("_aRecords") ?: json.optJSONArray("records") ?: JSONArray()
        buildList {
            for (i in 0 until records.length()) {
                val item = records.optJSONObject(i) ?: continue
                val id = item.optString("_idRow").ifBlank { item.optString("id") }
                if (id.isBlank()) continue
                val submitter = item.optJSONObject("_aSubmitter")
                add(ModItem(id, item.optString("_sName", "Untitled mod"), submitter?.optString("_sName") ?: "GameBanana creator", "https://gamebanana.com/mods/$id"))
            }
        }
    }
}
