# Funkin' Hub Mobile — Android source v0.3.0

A native Kotlin + Jetpack Compose Android app for discovering and managing Friday Night Funkin' V-Slice / Polymod mods.

## GameBanana integration in v0.3.0
- Search GameBanana's public API for Friday Night Funkin' mods.
- Open a mod detail dialog inside the app.
- Fetch downloadable files from the GameBanana Mod API (`_aFiles`).
- Show available file names, descriptions, and sizes.
- Download a selected file over HTTPS directly inside the app.
- Enforce a 300 MB download cap, ZIP entry limit, expanded-size limit, and ZIP path-traversal checks.
- Extract downloads into the app's private mod library and require `_polymod_meta.json` before staging.
- Import local ZIP files, browse staged mods, and copy a mod to a user-selected folder when Android grants write access.
- Launch the official FNF Android app when installed.

## Build an APK
This archive is an Android Studio project, not a compiled APK. To create an installable debug APK:
1. Install Android Studio and Android SDK 35.
2. Open this `FunkinHubAndroid` folder in Android Studio.
3. Allow Gradle to sync and download dependencies.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

A release APK needs a signing key configured in Android Studio/Gradle. No signing key is included.

## Android storage limitation
Android restricts third-party apps from writing to another app's protected `Android/data` or `Android/obb` folders on modern Android versions. Funkin' Hub can install only to a destination the user explicitly selects and Android permits. It does not use root, Shizuku, broad all-files access, or accessibility privileges to bypass those protections. If Android blocks the official game's folder, use FNF's own **Options → Open Data Folder** workflow and follow the official mod installation guide:
https://github.com/FunkinCrew/Funkin/blob/main/docs/INSTALLING_MODS.md

## Compatibility
The app checks for `_polymod_meta.json` and parses it as JSON. This is a format sanity check, not a guarantee that a mod is compatible with the exact installed game version. Psych Engine mods are not interchangeable with official V-Slice mods. Review the mod's description and target version before installing.

## API note
GameBanana content is retrieved from its public API. Mod availability, API response fields, creator-hosted downloads, and download URLs can change. The app accepts HTTPS download URLs only. Respect GameBanana's and each creator's terms and permissions.
